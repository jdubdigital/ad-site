<?php
/**
 * Plugin Name: Company Careers Board
 * Plugin URI: https://example.com/company-careers-board
 * Description: A white-label careers board for WordPress with searchable listings, branded styling, and fictional demo jobs for client handoff.
 * Version: 1.0.0
 * Author: OpenAI Codex
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: company-careers-board
 */

if (! defined('ABSPATH')) {
    exit;
}

define('CCB_VERSION', '1.0.0');
define('CCB_FILE', __FILE__);
define('CCB_PATH', plugin_dir_path(__FILE__));
define('CCB_URL', plugin_dir_url(__FILE__));

require_once CCB_PATH . 'includes/class-company-careers-board.php';

function company_careers_board()
{
    static $plugin = null;

    if (null === $plugin) {
        $plugin = new Company_Careers_Board();
    }

    return $plugin;
}

register_activation_hook(CCB_FILE, array('Company_Careers_Board', 'activate'));
register_deactivation_hook(CCB_FILE, array('Company_Careers_Board', 'deactivate'));

company_careers_board();
