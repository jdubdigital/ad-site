export const jobs = [
  {
    slug: "senior-frontend-engineer-remote",
    title: "Senior Frontend Engineer",
    company: "Demo Company",
    location: "Remote",
    type: "Full-time",
    salary: "$125,000-$150,000",
    posted: "2026-03-18",
    description: "We are looking for a Senior Frontend Engineer to help shape the next generation of client-facing product experiences. This role partners closely with design, product, and platform teams to build polished, high-performance web interfaces.",
    responsibilities: [
      "Build responsive product interfaces with modern JavaScript and component-based architecture",
      "Collaborate with product and design teams to translate workflows into scalable UI systems",
      "Improve front-end performance, accessibility, and maintainability across the application",
      "Contribute to testing strategy and release readiness for major launches"
    ],
    qualifications: [
      "5+ years of professional frontend engineering experience",
      "Strong knowledge of JavaScript, HTML, CSS, and modern UI patterns",
      "Experience working closely with designers in product-led teams",
      "Comfortable mentoring peers and shaping engineering standards"
    ],
    idealCandidate: [
      "Cares deeply about product quality and visual polish",
      "Balances speed with maintainable architecture",
      "Communicates clearly across technical and non-technical teams"
    ],
    benefits: [
      "Health, dental, and vision coverage",
      "Home office stipend",
      "Flexible PTO",
      "401(k) match"
    ],
    schedule: "Monday to Friday",
    workLocation: "Remote",
    aboutCompany: "This is fictional demo company copy included with the Company Careers Board plugin. Replace it with your client's real story during implementation.",
    education: "Bachelor's degree or equivalent experience",
    jobTypes: "Full-time, Permanent",
    applicationQuestions: [
      "Do you have experience shipping production user interfaces?",
      "Are you authorized to work in your current country of residence?"
    ]
  },
  {
    slug: "product-designer-hybrid-chicago",
    title: "Product Designer",
    company: "Demo Company",
    location: "Chicago, IL",
    type: "Full-time",
    salary: "$95,000-$120,000",
    posted: "2026-03-15",
    description: "We are hiring a Product Designer to own user flows, interface systems, and cross-functional collaboration for a growing SaaS platform. You will turn customer insight into intuitive, elegant experiences that are easy to use and easy to scale.",
    responsibilities: [
      "Lead UX and UI design work across customer-facing products",
      "Build and maintain reusable design patterns",
      "Run lightweight research and usability reviews to validate design decisions",
      "Partner with engineering during implementation and QA"
    ],
    qualifications: [
      "3+ years of product design experience in digital products",
      "Strong portfolio showing systems thinking and interaction design",
      "Experience with Figma and cross-functional collaboration",
      "Excellent communication and presentation skills"
    ],
    idealCandidate: [
      "Thinks in systems, not just screens",
      "Welcomes feedback and iterates quickly",
      "Enjoys partnering tightly with engineering and product"
    ],
    benefits: [
      "Medical, dental, and vision",
      "Annual learning stipend",
      "Hybrid work flexibility",
      "Paid parental leave"
    ],
    schedule: "Monday to Friday",
    workLocation: "Hybrid",
    aboutCompany: "This demo listing is included to help agencies and teams launch quickly with realistic sample content.",
    education: "Bachelor's degree preferred",
    jobTypes: "Full-time",
    applicationQuestions: [
      "Please share a link to your portfolio."
    ]
  },
  {
    slug: "customer-support-lead-austin",
    title: "Customer Support Lead",
    company: "Demo Company",
    location: "Austin, TX",
    type: "Full-time",
    salary: "$68,000-$82,000",
    posted: "2026-03-10",
    description: "The Customer Support Lead will oversee daily support operations, help improve workflows, and ensure customers receive fast, thoughtful assistance. This is a hands-on leadership role with a strong operational component.",
    responsibilities: [
      "Coach and support frontline support specialists",
      "Monitor ticket quality, response times, and escalation health",
      "Document recurring issues and improve internal workflows",
      "Partner with product and engineering on customer-impacting issues"
    ],
    qualifications: [
      "Experience leading or mentoring a customer support team",
      "Strong written communication skills",
      "Comfortable using help desk and reporting tools",
      "Able to balance empathy with operational discipline"
    ],
    idealCandidate: [
      "Stays calm under pressure",
      "Leads by example",
      "Turns repeated issues into process improvements"
    ],
    benefits: [
      "Comprehensive health coverage",
      "Quarterly wellness stipend",
      "Performance bonus eligibility",
      "Paid volunteer time"
    ],
    additionalPay: "Annual bonus",
    schedule: "Monday to Friday, occasional weekend coverage rotation",
    workLocation: "In person",
    aboutCompany: "Replace this fictional company description with a client-specific overview when deploying the plugin on a production website.",
    jobTypes: "Full-time",
    applicationQuestions: [
      "Have you led or mentored a support team before?"
    ]
  },
  {
    slug: "revenue-operations-analyst-remote",
    title: "Revenue Operations Analyst",
    company: "Demo Company",
    location: "Remote",
    type: "Full-time",
    salary: "$80,000-$98,000",
    posted: "2026-03-06",
    description: "We are seeking a Revenue Operations Analyst to improve funnel visibility, reporting accuracy, and cross-functional planning. This role supports sales, customer success, and finance with actionable insights and better operational tooling.",
    responsibilities: [
      "Maintain key reports and dashboards for pipeline and revenue performance",
      "Audit process gaps across CRM and handoff workflows",
      "Support forecasting and planning activities",
      "Partner with leadership on systems and data improvements"
    ],
    qualifications: [
      "Experience with CRM reporting and go-to-market operations",
      "Strong spreadsheet and analytical skills",
      "Comfortable translating ambiguous questions into clear reporting",
      "Attention to detail and process discipline"
    ],
    idealCandidate: [
      "Likes turning operational chaos into clarity",
      "Communicates recommendations clearly",
      "Can move between analytics and execution"
    ],
    benefits: [
      "Remote-first work environment",
      "401(k) match",
      "Home office budget",
      "Flexible PTO"
    ],
    schedule: "Monday to Friday",
    workLocation: "Remote",
    aboutCompany: "This listing is intentionally fictional so the plugin can be demoed or sold without tying the product to a single employer.",
    education: "Bachelor's degree or equivalent experience",
    jobTypes: "Full-time"
  },
  {
    slug: "warehouse-operations-supervisor-denver",
    title: "Warehouse Operations Supervisor",
    company: "Demo Company",
    location: "Denver, CO",
    type: "Full-time",
    salary: "$72,000-$86,000",
    posted: "2026-03-03",
    description: "The Warehouse Operations Supervisor leads daily fulfillment activity, coordinates staffing, and ensures that safety, quality, and shipping goals are met. The role is ideal for a process-minded operator who enjoys coaching teams and improving throughput.",
    responsibilities: [
      "Supervise daily warehouse operations and shift activity",
      "Track productivity, quality, and on-time shipping performance",
      "Lead safety routines, training, and workflow improvements",
      "Coordinate staffing and issue resolution across the floor"
    ],
    qualifications: [
      "Previous supervisory experience in warehouse or logistics environments",
      "Strong communication and scheduling skills",
      "Comfortable working with inventory and fulfillment systems",
      "Ability to work in a fast-paced operations setting"
    ],
    idealCandidate: [
      "Leads from the floor, not just the office",
      "Values consistency and accountability",
      "Looks for simple process improvements with measurable impact"
    ],
    benefits: [
      "Medical and dental coverage",
      "Paid time off",
      "Shift meal stipend",
      "Bonus program"
    ],
    additionalPay: "Quarterly performance bonus",
    schedule: "Day shift, Tuesday to Saturday",
    workLocation: "In person",
    aboutCompany: "Use this operations-oriented sample listing in demos where a non-tech example helps showcase the flexibility of the plugin.",
    jobTypes: "Full-time"
  },
  {
    slug: "people-operations-manager-new-york",
    title: "People Operations Manager",
    company: "Demo Company",
    location: "New York, NY",
    type: "Full-time",
    salary: "$105,000-$128,000",
    posted: "2026-02-27",
    description: "We are hiring a People Operations Manager to support employee experience, manager enablement, and people processes across a distributed organization. This role blends strategy, communication, and operational ownership.",
    responsibilities: [
      "Own and improve people operations processes across the employee lifecycle",
      "Support managers with onboarding, performance, and policy guidance",
      "Partner with leadership on engagement and culture initiatives",
      "Maintain accurate people documentation and reporting"
    ],
    qualifications: [
      "5+ years in HR, people operations, or employee experience roles",
      "Strong judgment and communication skills",
      "Experience balancing compliance, empathy, and execution",
      "Comfortable operating in growing organizations"
    ],
    idealCandidate: [
      "Builds trust quickly",
      "Improves process without becoming bureaucratic",
      "Cares about both people experience and operational clarity"
    ],
    benefits: [
      "Health, dental, and vision",
      "401(k) with employer match",
      "Professional development support",
      "Generous PTO"
    ],
    schedule: "Monday to Friday",
    workLocation: "Hybrid",
    aboutCompany: "All sample companies and listings in this plugin are fictional and intended only for demo or starter content.",
    education: "Bachelor's degree preferred",
    jobTypes: "Full-time"
  }
];
