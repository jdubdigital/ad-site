(function () {
  const boards = document.querySelectorAll(".ccb-board");
  if (!boards.length) {
    return;
  }

  boards.forEach((board) => {
    const dataNode = board.querySelector(".ccb-board__data");
    const preview = board.querySelector("[data-role='preview']");
    const list = board.querySelector("[data-role='job-list']");
    const search = board.querySelector(".ccb-board__search");
    const count = board.querySelector("[data-role='job-count']");
    const emptyState = board.querySelector("[data-role='empty-state']");

    if (!dataNode || !preview || !list || !search || !count || !emptyState) {
      return;
    }

    let payload = { jobs: [] };
    try {
      payload = JSON.parse(dataNode.textContent || "{}");
    } catch (error) {
      return;
    }

    const jobs = Array.isArray(payload.jobs) ? payload.jobs : [];
    const jobsBySlug = new Map(jobs.map((job) => [job.slug, job]));
    const cards = Array.from(list.querySelectorAll(".ccb-job-card"));
    const desktopQuery = window.matchMedia("(min-width: 1024px)");

    const setActiveCard = (slug) => {
      cards.forEach((card) => {
        card.classList.toggle("is-active", card.dataset.jobSlug === slug);
      });
    };

    const renderPreview = (job) => {
      preview.innerHTML = `
        <div class="ccb-job-preview">
          <div class="ccb-job-preview__top">
            <h3>${escapeHtml(job.title || "")}</h3>
            <p>${escapeHtml(`${job.company || ""} - ${job.location || ""}`)}</p>
            ${job.posting_label ? `<p class="ccb-job-card__date">${escapeHtml(job.posting_label)}</p>` : ""}
          </div>
          <div class="ccb-job-preview__meta">
            ${job.type ? `<span class="ccb-chip">${escapeHtml(job.type)}</span>` : ""}
            ${job.salary ? `<span class="ccb-note">${escapeHtml(job.salary)}</span>` : ""}
          </div>
          <div class="ccb-job-preview__actions">
            <a class="ccb-button ccb-button--primary" href="${escapeAttribute(job.apply_url || "#")}" target="_blank" rel="noopener noreferrer">Apply Now</a>
            <a class="ccb-button ccb-button--secondary" href="${escapeAttribute(job.url || "#")}">View full job</a>
          </div>
          ${renderSections(job)}
        </div>
      `;
    };

    const updateVisibleState = () => {
      const query = search.value.trim().toLowerCase();
      const visibleCards = cards.filter((card) => {
        const match =
          !query ||
          card.dataset.title.includes(query) ||
          card.dataset.company.includes(query) ||
          card.dataset.location.includes(query);

        card.hidden = !match;
        return match;
      });

      count.textContent = String(visibleCards.length);
      emptyState.hidden = visibleCards.length > 0;

      if (!visibleCards.length) {
        preview.innerHTML =
          '<div class="ccb-preview-empty">No jobs found. Try a different search.</div>';
        return;
      }

      const activeVisible =
        visibleCards.find((card) => card.classList.contains("is-active")) ||
        visibleCards[0];

      const activeJob = jobsBySlug.get(activeVisible.dataset.jobSlug);
      if (activeJob) {
        setActiveCard(activeJob.slug);
        renderPreview(activeJob);
      }
    };

    cards.forEach((card) => {
      card.addEventListener("click", (event) => {
        if (!desktopQuery.matches) {
          return;
        }

        event.preventDefault();
        const job = jobsBySlug.get(card.dataset.jobSlug);
        if (!job) {
          return;
        }

        setActiveCard(job.slug);
        renderPreview(job);
      });
    });

    search.addEventListener("input", updateVisibleState);
  });

  function renderSections(job) {
    return [
      renderTextSection("About the Company", job.about_company),
      renderTextSection("Role Summary", job.description),
      renderListSection("Responsibilities", job.responsibilities),
      renderListSection("Qualifications", job.qualifications),
      renderListSection("Ideal Candidate", job.ideal_candidate),
      renderTextSection("Additional Pay", job.additional_pay),
      renderListSection("Benefits", job.benefits),
      renderTextSection("Schedule", job.schedule),
      renderTextSection("Commute / Relocation", job.ability_to_commute),
      renderListSection("Application Questions", job.application_questions),
      renderTextSection("Education", job.education),
      renderTextSection("Work Location", job.work_location),
      renderTextSection("Job Types", job.job_types),
    ]
      .filter(Boolean)
      .join("");
  }

  function renderTextSection(label, value) {
    if (!value) {
      return "";
    }

    return `
      <section class="ccb-job-section">
        <h4>${escapeHtml(label)}</h4>
        ${String(value)
          .split(/\n+/)
          .filter(Boolean)
          .map((line) => `<p>${escapeHtml(line)}</p>`)
          .join("")}
      </section>
    `;
  }

  function renderListSection(label, items) {
    if (!Array.isArray(items) || !items.length) {
      return "";
    }

    return `
      <section class="ccb-job-section">
        <h4>${escapeHtml(label)}</h4>
        <ul>
          ${items.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}
        </ul>
      </section>
    `;
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function escapeAttribute(value) {
    return escapeHtml(value);
  }
})();
