import { jobs } from "./sample-jobs.js";

const button = document.getElementById("ccb-import-button");
const status = document.getElementById("ccb-import-status");

if (button && status && window.ccbImportConfig) {
  button.addEventListener("click", async () => {
    button.disabled = true;
    status.textContent = "Importing demo jobs...";

    try {
      const body = new URLSearchParams({
        action: window.ccbImportConfig.action,
        nonce: window.ccbImportConfig.nonce,
        jobs: JSON.stringify(jobs),
      });

      const response = await fetch(window.ccbImportConfig.ajaxUrl, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        },
        body: body.toString(),
      });

      const payload = await response.json();

      if (!response.ok || !payload.success) {
        const message =
          payload && payload.data && payload.data.message
            ? payload.data.message
            : "The demo import could not be completed.";
        throw new Error(message);
      }

      status.textContent = payload.data.message;
    } catch (error) {
      status.textContent =
        error instanceof Error ? error.message : "The demo import failed.";
    } finally {
      button.disabled = false;
    }
  });
}
