<?php

if (! defined('ABSPATH')) {
    exit;
}

class Company_Careers_Board
{
    const POST_TYPE = 'ccb_job';
    const SETTINGS_KEY = 'ccb_settings';
    const AJAX_ACTION = 'ccb_import_demo_jobs';

    /**
     * @var array<string, array<string, mixed>>
     */
    private $meta_fields = array();

    public function __construct()
    {
        $this->meta_fields = $this->get_meta_fields();

        add_action('init', array($this, 'register_post_type'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('add_meta_boxes', array($this, 'register_meta_box'));
        add_action('save_post_' . self::POST_TYPE, array($this, 'save_job_meta'));
        add_action('admin_menu', array($this, 'register_admin_page'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('wp_ajax_' . self::AJAX_ACTION, array($this, 'handle_demo_import'));
        add_action('manage_' . self::POST_TYPE . '_posts_columns', array($this, 'register_admin_columns'));
        add_action('manage_' . self::POST_TYPE . '_posts_custom_column', array($this, 'render_admin_columns'), 10, 2);
        add_filter('script_loader_tag', array($this, 'mark_module_scripts'), 10, 3);

        add_shortcode('company_careers_board', array($this, 'render_board_shortcode'));
        add_shortcode('ccb_jobs', array($this, 'render_board_shortcode'));
    }

    public static function activate()
    {
        $plugin = new self();
        $plugin->register_post_type();
        flush_rewrite_rules();
    }

    public static function deactivate()
    {
        flush_rewrite_rules();
    }

    public function register_post_type()
    {
        $labels = array(
            'name'               => __('Careers', 'company-careers-board'),
            'singular_name'      => __('Job Listing', 'company-careers-board'),
            'menu_name'          => __('Careers Board', 'company-careers-board'),
            'add_new'            => __('Add Job', 'company-careers-board'),
            'add_new_item'       => __('Add New Job', 'company-careers-board'),
            'edit_item'          => __('Edit Job', 'company-careers-board'),
            'new_item'           => __('New Job', 'company-careers-board'),
            'view_item'          => __('View Job', 'company-careers-board'),
            'search_items'       => __('Search Jobs', 'company-careers-board'),
            'not_found'          => __('No jobs found', 'company-careers-board'),
            'not_found_in_trash' => __('No jobs found in Trash', 'company-careers-board'),
        );

        register_post_type(
            self::POST_TYPE,
            array(
                'labels'             => $labels,
                'public'             => false,
                'show_ui'            => true,
                'show_in_menu'       => true,
                'show_in_rest'       => false,
                'menu_icon'          => 'dashicons-id',
                'supports'           => array('title'),
                'capability_type'    => 'post',
                'has_archive'        => false,
                'rewrite'            => false,
                'publicly_queryable' => false,
            )
        );
    }

    public function register_settings()
    {
        register_setting(
            'ccb_settings_group',
            self::SETTINGS_KEY,
            array(
                'type'              => 'array',
                'sanitize_callback' => array($this, 'sanitize_settings'),
                'default'           => $this->default_settings(),
            )
        );
    }

    public function sanitize_settings($settings)
    {
        $settings = is_array($settings) ? $settings : array();
        $defaults = $this->default_settings();

        return array(
            'company_name'      => sanitize_text_field(isset($settings['company_name']) ? $settings['company_name'] : $defaults['company_name']),
            'eyebrow'           => sanitize_text_field(isset($settings['eyebrow']) ? $settings['eyebrow'] : $defaults['eyebrow']),
            'headline'          => sanitize_text_field(isset($settings['headline']) ? $settings['headline'] : $defaults['headline']),
            'default_apply_url' => esc_url_raw(isset($settings['default_apply_url']) ? $settings['default_apply_url'] : $defaults['default_apply_url']),
            'logo_url'          => esc_url_raw(isset($settings['logo_url']) ? $settings['logo_url'] : ''),
            'accent_color'      => $this->sanitize_hex(isset($settings['accent_color']) ? $settings['accent_color'] : $defaults['accent_color'], $defaults['accent_color']),
            'surface_color'     => $this->sanitize_hex(isset($settings['surface_color']) ? $settings['surface_color'] : $defaults['surface_color'], $defaults['surface_color']),
        );
    }

    public function register_meta_box()
    {
        add_meta_box(
            'ccb-job-details',
            __('Job Details', 'company-careers-board'),
            array($this, 'render_meta_box'),
            self::POST_TYPE,
            'normal',
            'high'
        );
    }

    public function render_meta_box($post)
    {
        wp_nonce_field('ccb_save_job', 'ccb_job_nonce');

        echo '<table class="form-table" role="presentation"><tbody>';

        foreach ($this->meta_fields as $key => $field) {
            $meta_key = $this->meta_key($key);
            $value = get_post_meta($post->ID, $meta_key, true);

            if ('list' === $field['type'] && is_array($value)) {
                $value = implode("\n", $value);
            }

            if (! is_string($value)) {
                $value = '';
            }

            echo '<tr>';
            echo '<th scope="row"><label for="' . esc_attr($meta_key) . '">' . esc_html($field['label']) . '</label></th>';
            echo '<td>';

            if ('textarea' === $field['type'] || 'list' === $field['type']) {
                printf(
                    '<textarea class="large-text" rows="%1$d" id="%2$s" name="%2$s">%3$s</textarea>',
                    (int) $field['rows'],
                    esc_attr($meta_key),
                    esc_textarea($value)
                );
            } else {
                $input_type = isset($field['input_type']) ? $field['input_type'] : 'text';

                printf(
                    '<input class="regular-text" type="%1$s" id="%2$s" name="%2$s" value="%3$s" />',
                    esc_attr($input_type),
                    esc_attr($meta_key),
                    esc_attr($value)
                );
            }

            if (! empty($field['description'])) {
                echo '<p class="description">' . esc_html($field['description']) . '</p>';
            }

            echo '</td></tr>';
        }

        echo '</tbody></table>';
    }

    public function save_job_meta($post_id)
    {
        if (! isset($_POST['ccb_job_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ccb_job_nonce'])), 'ccb_save_job')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (! current_user_can('edit_post', $post_id)) {
            return;
        }

        foreach ($this->meta_fields as $key => $field) {
            $meta_key = $this->meta_key($key);
            $raw = isset($_POST[$meta_key]) ? wp_unslash($_POST[$meta_key]) : '';

            if ('url' === $field['type']) {
                $value = esc_url_raw((string) $raw);
            } elseif ('date' === $field['type']) {
                $value = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $raw) ? (string) $raw : '';
            } elseif ('list' === $field['type']) {
                $items = preg_split('/\r\n|\r|\n/', (string) $raw);
                $items = array_filter(array_map('sanitize_text_field', $items));
                $value = array_values($items);
            } elseif ('textarea' === $field['type']) {
                $value = sanitize_textarea_field((string) $raw);
            } else {
                $value = sanitize_text_field((string) $raw);
            }

            if ((is_string($value) && '' === $value) || (is_array($value) && empty($value))) {
                delete_post_meta($post_id, $meta_key);
            } else {
                update_post_meta($post_id, $meta_key, $value);
            }
        }
    }

    public function register_admin_page()
    {
        add_submenu_page(
            'edit.php?post_type=' . self::POST_TYPE,
            __('Setup', 'company-careers-board'),
            __('Setup', 'company-careers-board'),
            'manage_options',
            'ccb-setup',
            array($this, 'render_admin_page')
        );
    }

    public function render_admin_page()
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        $settings = $this->get_settings();
        $jobs_url = admin_url('edit.php?post_type=' . self::POST_TYPE);

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Company Careers Board', 'company-careers-board') . '</h1>';
        echo '<p>' . esc_html__('A white-label careers board for agencies, freelancers, and product sellers. Use the brand settings below, then place [company_careers_board] on any page.', 'company-careers-board') . '</p>';

        echo '<form method="post" action="options.php">';
        settings_fields('ccb_settings_group');

        echo '<table class="form-table" role="presentation"><tbody>';
        $this->render_settings_row('company_name', __('Company Name', 'company-careers-board'), $settings['company_name']);
        $this->render_settings_row('eyebrow', __('Eyebrow Text', 'company-careers-board'), $settings['eyebrow']);
        $this->render_settings_row('headline', __('Headline', 'company-careers-board'), $settings['headline']);
        $this->render_settings_row('default_apply_url', __('Default Apply URL', 'company-careers-board'), $settings['default_apply_url'], 'url');
        $this->render_settings_row('logo_url', __('Logo URL', 'company-careers-board'), $settings['logo_url'], 'url', __('Optional. Leave blank to show the company initials instead.', 'company-careers-board'));
        $this->render_settings_row('accent_color', __('Accent Color', 'company-careers-board'), $settings['accent_color'], 'text', __('Hex color, for example #D1452F.', 'company-careers-board'));
        $this->render_settings_row('surface_color', __('Surface Color', 'company-careers-board'), $settings['surface_color'], 'text', __('Hex color for cards and content surfaces.', 'company-careers-board'));
        echo '</tbody></table>';

        submit_button(__('Save Brand Settings', 'company-careers-board'));
        echo '</form>';

        echo '<hr />';
        echo '<h2>' . esc_html__('Quick Start', 'company-careers-board') . '</h2>';
        echo '<ol>';
        echo '<li>' . esc_html__('Manage jobs under Careers Board > Careers.', 'company-careers-board') . '</li>';
        echo '<li>' . esc_html__('Add [company_careers_board] to a page.', 'company-careers-board') . '</li>';
        echo '<li>' . esc_html__('Use the demo import below if you want fake listings for sales demos or staging sites.', 'company-careers-board') . '</li>';
        echo '</ol>';
        echo '<p><a class="button button-secondary" href="' . esc_url($jobs_url) . '">' . esc_html__('Manage Jobs', 'company-careers-board') . '</a></p>';

        echo '<hr />';
        echo '<h2>' . esc_html__('Import Demo Jobs', 'company-careers-board') . '</h2>';
        echo '<p>' . esc_html__('Imports fictional sample jobs and updates them by slug, so you can safely rerun it on demos.', 'company-careers-board') . '</p>';
        echo '<button type="button" class="button button-primary" id="ccb-import-button">' . esc_html__('Import Demo Jobs', 'company-careers-board') . '</button>';
        echo '<p id="ccb-import-status" style="margin-top:12px;"></p>';
        echo '</div>';
    }

    public function enqueue_admin_assets($hook)
    {
        if ('ccb_job_page_ccb-setup' !== $hook) {
            return;
        }

        wp_enqueue_script(
            'ccb-admin-import',
            CCB_URL . 'assets/js/admin-import.js',
            array(),
            CCB_VERSION,
            true
        );

        wp_add_inline_script(
            'ccb-admin-import',
            'window.ccbImportConfig = ' . wp_json_encode(
                array(
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce'   => wp_create_nonce(self::AJAX_ACTION),
                    'action'  => self::AJAX_ACTION,
                )
            ) . ';',
            'before'
        );
    }

    public function mark_module_scripts($tag, $handle, $src)
    {
        if ('ccb-admin-import' !== $handle) {
            return $tag;
        }

        return sprintf('<script type="module" src="%s"></script>', esc_url($src));
    }

    public function register_admin_columns($columns)
    {
        $columns['ccb_company'] = __('Company', 'company-careers-board');
        $columns['ccb_location'] = __('Location', 'company-careers-board');
        $columns['ccb_type'] = __('Type', 'company-careers-board');
        $columns['ccb_posting_date'] = __('Posting Date', 'company-careers-board');

        return $columns;
    }

    public function render_admin_columns($column, $post_id)
    {
        if ('ccb_company' === $column) {
            echo esc_html((string) get_post_meta($post_id, $this->meta_key('company'), true));
        } elseif ('ccb_location' === $column) {
            echo esc_html((string) get_post_meta($post_id, $this->meta_key('location'), true));
        } elseif ('ccb_type' === $column) {
            echo esc_html((string) get_post_meta($post_id, $this->meta_key('type'), true));
        } elseif ('ccb_posting_date' === $column) {
            echo esc_html((string) get_post_meta($post_id, $this->meta_key('posting_date'), true));
        }
    }

    public function render_board_shortcode($atts)
    {
        $atts = shortcode_atts(
            array(
                'title' => '',
            ),
            $atts,
            'company_careers_board'
        );

        $jobs = $this->get_jobs();

        if (empty($jobs)) {
            return $this->render_empty_state();
        }

        $slug = '';
        if (isset($_GET['job'])) {
            $slug = sanitize_title(wp_unslash($_GET['job']));
        }

        if ('' !== $slug) {
            $job = $this->find_job_by_slug($jobs, $slug);
            if (! $job) {
                return $this->render_missing_job();
            }

            return $this->render_job_detail($job, $atts['title']);
        }

        wp_enqueue_style(
            'ccb-public',
            CCB_URL . 'assets/css/public.css',
            array(),
            CCB_VERSION
        );

        wp_enqueue_script(
            'ccb-public',
            CCB_URL . 'assets/js/public.js',
            array(),
            CCB_VERSION,
            true
        );

        return $this->render_job_board($jobs, $atts['title']);
    }

    public function handle_demo_import()
    {
        if (! current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('You do not have permission to import demo jobs.', 'company-careers-board')), 403);
        }

        check_ajax_referer(self::AJAX_ACTION, 'nonce');

        $payload = isset($_POST['jobs']) ? wp_unslash($_POST['jobs']) : '';
        $jobs = json_decode((string) $payload, true);

        if (! is_array($jobs)) {
            wp_send_json_error(array('message' => __('Invalid demo job payload.', 'company-careers-board')), 400);
        }

        $imported = 0;

        foreach ($jobs as $job) {
            if (! is_array($job) || empty($job['title']) || empty($job['slug'])) {
                continue;
            }

            if ($this->upsert_demo_job($job)) {
                ++$imported;
            }
        }

        wp_send_json_success(
            array(
                'message' => sprintf(
                    /* translators: %d: number of jobs */
                    __('Imported or updated %d demo jobs.', 'company-careers-board'),
                    $imported
                ),
                'count' => $imported,
            )
        );
    }

    private function render_job_board($jobs, $shortcode_title)
    {
        $settings = $this->get_settings();
        $display_title = '' !== $shortcode_title ? $shortcode_title : $settings['headline'];
        $instance_id = 'ccb-board-' . wp_generate_uuid4();
        $preview_job = reset($jobs);
        $data = array('jobs' => array_values($jobs));

        ob_start();
        ?>
        <section class="ccb-board" id="<?php echo esc_attr($instance_id); ?>" style="<?php echo esc_attr($this->css_variables($settings)); ?>">
            <div class="ccb-board__brand">
                <?php echo $this->render_brand_mark($settings); ?>
                <div>
                    <p class="ccb-board__eyebrow"><?php echo esc_html($settings['eyebrow']); ?></p>
                    <h2 class="ccb-board__title"><?php echo esc_html($display_title); ?></h2>
                </div>
            </div>

            <div class="ccb-board__toolbar">
                <label class="screen-reader-text" for="<?php echo esc_attr($instance_id . '-search'); ?>"><?php esc_html_e('Search jobs', 'company-careers-board'); ?></label>
                <input class="ccb-board__search" id="<?php echo esc_attr($instance_id . '-search'); ?>" type="search" placeholder="<?php esc_attr_e('Search jobs, company, or location', 'company-careers-board'); ?>" />
                <p class="ccb-board__count"><span data-role="job-count"><?php echo esc_html((string) count($jobs)); ?></span> <?php esc_html_e('jobs found', 'company-careers-board'); ?></p>
            </div>

            <div class="ccb-board__layout">
                <div class="ccb-board__list" data-role="job-list">
                    <?php foreach ($jobs as $index => $job) : ?>
                        <?php echo $this->render_job_card($job, 0 === $index); ?>
                    <?php endforeach; ?>
                    <div class="ccb-board__empty" data-role="empty-state" hidden>
                        <?php esc_html_e('No jobs found. Try a different search.', 'company-careers-board'); ?>
                    </div>
                </div>

                <aside class="ccb-board__preview" data-role="preview">
                    <?php echo $this->render_job_preview($preview_job); ?>
                </aside>
            </div>

            <script type="application/json" class="ccb-board__data"><?php echo wp_json_encode($data); ?></script>
        </section>
        <?php

        return (string) ob_get_clean();
    }

    private function render_job_card($job, $selected = false)
    {
        $classes = array('ccb-job-card');
        if ($selected) {
            $classes[] = 'is-active';
        }

        ob_start();
        ?>
        <a
            class="<?php echo esc_attr(implode(' ', $classes)); ?>"
            href="<?php echo esc_url($job['url']); ?>"
            data-job-slug="<?php echo esc_attr($job['slug']); ?>"
            data-title="<?php echo esc_attr(strtolower($job['title'])); ?>"
            data-company="<?php echo esc_attr(strtolower($job['company'])); ?>"
            data-location="<?php echo esc_attr(strtolower($job['location'])); ?>"
        >
            <div class="ccb-job-card__header">
                <div>
                    <h3><?php echo esc_html($job['title']); ?></h3>
                    <p><?php echo esc_html($job['company'] . ' - ' . $job['location']); ?></p>
                    <?php if (! empty($job['posting_label'])) : ?>
                        <p class="ccb-job-card__date"><?php echo esc_html($job['posting_label']); ?></p>
                    <?php endif; ?>
                </div>
                <?php if (! empty($job['type'])) : ?>
                    <span class="ccb-chip"><?php echo esc_html($job['type']); ?></span>
                <?php endif; ?>
            </div>
            <?php if (! empty($job['description'])) : ?>
                <p class="ccb-job-card__summary"><?php echo esc_html($this->excerpt_text($job['description'], 170)); ?></p>
            <?php endif; ?>
        </a>
        <?php

        return (string) ob_get_clean();
    }

    private function render_job_preview($job)
    {
        ob_start();
        ?>
        <div class="ccb-job-preview">
            <div class="ccb-job-preview__top">
                <h3><?php echo esc_html($job['title']); ?></h3>
                <p><?php echo esc_html($job['company'] . ' - ' . $job['location']); ?></p>
                <?php if (! empty($job['posting_label'])) : ?>
                    <p class="ccb-job-card__date"><?php echo esc_html($job['posting_label']); ?></p>
                <?php endif; ?>
            </div>

            <div class="ccb-job-preview__meta">
                <?php if (! empty($job['type'])) : ?>
                    <span class="ccb-chip"><?php echo esc_html($job['type']); ?></span>
                <?php endif; ?>
                <?php if (! empty($job['salary'])) : ?>
                    <span class="ccb-note"><?php echo esc_html($job['salary']); ?></span>
                <?php endif; ?>
            </div>

            <div class="ccb-job-preview__actions">
                <a class="ccb-button ccb-button--primary" href="<?php echo esc_url($job['apply_url']); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Apply Now', 'company-careers-board'); ?></a>
                <a class="ccb-button ccb-button--secondary" href="<?php echo esc_url($job['url']); ?>"><?php esc_html_e('View full job', 'company-careers-board'); ?></a>
            </div>

            <?php echo $this->render_job_sections($job); ?>
        </div>
        <?php

        return (string) ob_get_clean();
    }

    private function render_job_detail($job, $shortcode_title)
    {
        $settings = $this->get_settings();
        $display_title = '' !== $shortcode_title ? $shortcode_title : $settings['headline'];
        $back_url = remove_query_arg('job');

        wp_enqueue_style(
            'ccb-public',
            CCB_URL . 'assets/css/public.css',
            array(),
            CCB_VERSION
        );

        ob_start();
        ?>
        <section class="ccb-board ccb-board--detail" style="<?php echo esc_attr($this->css_variables($settings)); ?>">
            <div class="ccb-board__brand">
                <?php echo $this->render_brand_mark($settings); ?>
                <div>
                    <p class="ccb-board__eyebrow"><?php echo esc_html($settings['eyebrow']); ?></p>
                    <h2 class="ccb-board__title"><?php echo esc_html($display_title); ?></h2>
                </div>
            </div>

            <article class="ccb-job-detail">
                <p class="ccb-job-detail__back"><a href="<?php echo esc_url($back_url); ?>"><?php esc_html_e('<- Back to all jobs', 'company-careers-board'); ?></a></p>
                <h1><?php echo esc_html($job['title']); ?></h1>
                <p class="ccb-job-detail__meta"><?php echo esc_html($job['company'] . ' - ' . $job['location']); ?></p>

                <div class="ccb-job-preview__meta">
                    <?php if (! empty($job['type'])) : ?>
                        <span class="ccb-chip"><?php echo esc_html($job['type']); ?></span>
                    <?php endif; ?>
                    <?php if (! empty($job['salary'])) : ?>
                        <span class="ccb-note"><?php echo esc_html($job['salary']); ?></span>
                    <?php endif; ?>
                    <?php if (! empty($job['posting_label'])) : ?>
                        <span class="ccb-note"><?php echo esc_html($job['posting_label']); ?></span>
                    <?php endif; ?>
                </div>

                <div class="ccb-job-preview__actions">
                    <a class="ccb-button ccb-button--primary" href="<?php echo esc_url($job['apply_url']); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Apply Now', 'company-careers-board'); ?></a>
                    <a class="ccb-button ccb-button--secondary" href="<?php echo esc_url($back_url); ?>"><?php esc_html_e('Back to Listings', 'company-careers-board'); ?></a>
                </div>

                <?php echo $this->render_job_sections($job); ?>
            </article>
        </section>
        <?php

        return (string) ob_get_clean();
    }

    private function render_job_sections($job)
    {
        $sections = array(
            'about_company'         => __('About the Company', 'company-careers-board'),
            'description'           => __('Role Summary', 'company-careers-board'),
            'responsibilities'      => __('Responsibilities', 'company-careers-board'),
            'qualifications'        => __('Qualifications', 'company-careers-board'),
            'ideal_candidate'       => __('Ideal Candidate', 'company-careers-board'),
            'additional_pay'        => __('Additional Pay', 'company-careers-board'),
            'benefits'              => __('Benefits', 'company-careers-board'),
            'schedule'              => __('Schedule', 'company-careers-board'),
            'ability_to_commute'    => __('Commute / Relocation', 'company-careers-board'),
            'application_questions' => __('Application Questions', 'company-careers-board'),
            'education'             => __('Education', 'company-careers-board'),
            'work_location'         => __('Work Location', 'company-careers-board'),
            'job_types'             => __('Job Types', 'company-careers-board'),
        );

        ob_start();

        foreach ($sections as $key => $label) {
            if (empty($job[$key])) {
                continue;
            }

            echo '<section class="ccb-job-section">';
            echo '<h4>' . esc_html($label) . '</h4>';

            if (is_array($job[$key])) {
                echo '<ul>';
                foreach ($job[$key] as $item) {
                    echo '<li>' . esc_html($item) . '</li>';
                }
                echo '</ul>';
            } else {
                echo wpautop(esc_html($job[$key]));
            }

            echo '</section>';
        }

        return (string) ob_get_clean();
    }

    private function render_missing_job()
    {
        wp_enqueue_style('ccb-public', CCB_URL . 'assets/css/public.css', array(), CCB_VERSION);

        return '<section class="ccb-board ccb-board--detail"><article class="ccb-job-detail"><p class="ccb-job-detail__back"><a href="' . esc_url(remove_query_arg('job')) . '">' . esc_html__('<- Back to all jobs', 'company-careers-board') . '</a></p><h1>' . esc_html__('Job Not Found', 'company-careers-board') . '</h1><p>' . esc_html__('The requested listing does not exist or is no longer available.', 'company-careers-board') . '</p></article></section>';
    }

    private function render_empty_state()
    {
        return '<div class="ccb-empty"><p>' . esc_html__('No jobs are available yet. Add jobs in Careers Board > Careers or import the demo listings from the Setup screen.', 'company-careers-board') . '</p></div>';
    }

    private function get_jobs()
    {
        $posts = get_posts(
            array(
                'post_type'      => self::POST_TYPE,
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'orderby'        => 'date',
                'order'          => 'DESC',
            )
        );

        $jobs = array();
        foreach ($posts as $post) {
            $jobs[] = $this->build_job_data($post);
        }

        usort(
            $jobs,
            function ($left, $right) {
                return strcmp($right['posting_date'], $left['posting_date']);
            }
        );

        return $jobs;
    }

    private function build_job_data($post)
    {
        $posting_date = (string) get_post_meta($post->ID, $this->meta_key('posting_date'), true);
        if ('' === $posting_date) {
            $posting_date = get_the_date('Y-m-d', $post);
        }

        $company = (string) get_post_meta($post->ID, $this->meta_key('company'), true);
        if ('' === $company) {
            $company = $this->get_settings()['company_name'];
        }

        $apply_url = (string) get_post_meta($post->ID, $this->meta_key('apply_url'), true);
        if ('' === $apply_url) {
            $apply_url = $this->get_settings()['default_apply_url'];
        }

        $page_id = get_queried_object_id();
        $base_url = $page_id ? get_permalink($page_id) : home_url('/');

        return array(
            'id'                    => (int) $post->ID,
            'slug'                  => $post->post_name,
            'title'                 => $post->post_title,
            'company'               => $company,
            'location'              => (string) get_post_meta($post->ID, $this->meta_key('location'), true),
            'type'                  => (string) get_post_meta($post->ID, $this->meta_key('type'), true),
            'salary'                => (string) get_post_meta($post->ID, $this->meta_key('salary'), true),
            'description'           => (string) get_post_meta($post->ID, $this->meta_key('description'), true),
            'about_company'         => (string) get_post_meta($post->ID, $this->meta_key('about_company'), true),
            'additional_pay'        => (string) get_post_meta($post->ID, $this->meta_key('additional_pay'), true),
            'benefits'              => $this->normalize_meta_list(get_post_meta($post->ID, $this->meta_key('benefits'), true)),
            'responsibilities'      => $this->normalize_meta_list(get_post_meta($post->ID, $this->meta_key('responsibilities'), true)),
            'qualifications'        => $this->normalize_meta_list(get_post_meta($post->ID, $this->meta_key('qualifications'), true)),
            'ideal_candidate'       => $this->normalize_meta_list(get_post_meta($post->ID, $this->meta_key('ideal_candidate'), true)),
            'application_questions' => $this->normalize_meta_list(get_post_meta($post->ID, $this->meta_key('application_questions'), true)),
            'schedule'              => (string) get_post_meta($post->ID, $this->meta_key('schedule'), true),
            'ability_to_commute'    => (string) get_post_meta($post->ID, $this->meta_key('ability_to_commute'), true),
            'education'             => (string) get_post_meta($post->ID, $this->meta_key('education'), true),
            'work_location'         => (string) get_post_meta($post->ID, $this->meta_key('work_location'), true),
            'job_types'             => (string) get_post_meta($post->ID, $this->meta_key('job_types'), true),
            'posting_date'          => $posting_date,
            'posting_label'         => $this->format_posting_date($posting_date),
            'apply_url'             => $apply_url,
            'url'                   => add_query_arg('job', $post->post_name, $base_url),
        );
    }

    private function find_job_by_slug($jobs, $slug)
    {
        foreach ($jobs as $job) {
            if ($job['slug'] === $slug) {
                return $job;
            }
        }

        return null;
    }

    private function upsert_demo_job($job)
    {
        $slug = sanitize_title((string) $job['slug']);
        $existing = get_posts(
            array(
                'name'           => $slug,
                'post_type'      => self::POST_TYPE,
                'post_status'    => array('publish', 'draft', 'pending', 'private'),
                'posts_per_page' => 1,
                'fields'         => 'ids',
            )
        );

        $postarr = array(
            'post_type'   => self::POST_TYPE,
            'post_status' => 'publish',
            'post_title'  => sanitize_text_field((string) $job['title']),
            'post_name'   => $slug,
        );

        if (! empty($existing)) {
            $postarr['ID'] = (int) $existing[0];
            $post_id = wp_update_post(wp_slash($postarr), true);
        } else {
            $post_id = wp_insert_post(wp_slash($postarr), true);
        }

        if (is_wp_error($post_id) || ! $post_id) {
            return 0;
        }

        $seed_map = array(
            'company'               => $this->get_settings()['company_name'],
            'location'              => isset($job['location']) ? $job['location'] : '',
            'type'                  => isset($job['type']) ? $job['type'] : '',
            'salary'                => isset($job['salary']) ? $job['salary'] : '',
            'description'           => isset($job['description']) ? $job['description'] : '',
            'about_company'         => isset($job['aboutCompany']) ? $job['aboutCompany'] : '',
            'responsibilities'      => isset($job['responsibilities']) ? $job['responsibilities'] : array(),
            'qualifications'        => isset($job['qualifications']) ? $job['qualifications'] : array(),
            'ideal_candidate'       => isset($job['idealCandidate']) ? $job['idealCandidate'] : array(),
            'additional_pay'        => isset($job['additionalPay']) ? $job['additionalPay'] : '',
            'benefits'              => isset($job['benefits']) ? $job['benefits'] : array(),
            'schedule'              => isset($job['schedule']) ? $job['schedule'] : '',
            'ability_to_commute'    => isset($job['abilityToCommute']) ? $job['abilityToCommute'] : '',
            'application_questions' => isset($job['applicationQuestions']) ? $job['applicationQuestions'] : array(),
            'education'             => isset($job['education']) ? $job['education'] : '',
            'work_location'         => isset($job['workLocation']) ? $job['workLocation'] : '',
            'job_types'             => isset($job['jobTypes']) ? $job['jobTypes'] : '',
            'posting_date'          => isset($job['posted']) ? sanitize_text_field((string) $job['posted']) : current_time('Y-m-d'),
            'apply_url'             => isset($job['applyUrl']) ? $job['applyUrl'] : $this->get_settings()['default_apply_url'],
        );

        foreach ($seed_map as $key => $value) {
            $definition = isset($this->meta_fields[$key]) ? $this->meta_fields[$key] : array('type' => 'text');
            $meta_key = $this->meta_key($key);

            if ('list' === $definition['type']) {
                $value = is_array($value) ? array_values(array_filter(array_map('sanitize_text_field', $value))) : array();
            } elseif ('textarea' === $definition['type']) {
                $value = sanitize_textarea_field((string) $value);
            } elseif ('url' === $definition['type']) {
                $value = esc_url_raw((string) $value);
            } else {
                $value = sanitize_text_field((string) $value);
            }

            if ((is_string($value) && '' === $value) || (is_array($value) && empty($value))) {
                delete_post_meta($post_id, $meta_key);
            } else {
                update_post_meta($post_id, $meta_key, $value);
            }
        }

        return (int) $post_id;
    }

    private function get_settings()
    {
        return wp_parse_args((array) get_option(self::SETTINGS_KEY, array()), $this->default_settings());
    }

    private function default_settings()
    {
        return array(
            'company_name'      => __('Demo Company', 'company-careers-board'),
            'eyebrow'           => __('Careers', 'company-careers-board'),
            'headline'          => __('Join Our Team', 'company-careers-board'),
            'default_apply_url' => 'https://example.com/careers',
            'logo_url'          => '',
            'accent_color'      => '#d1452f',
            'surface_color'     => '#ffffff',
        );
    }

    private function render_brand_mark($settings)
    {
        $company_name = isset($settings['company_name']) ? (string) $settings['company_name'] : __('Company', 'company-careers-board');

        if (! empty($settings['logo_url'])) {
            return '<div class="ccb-brand-mark"><img src="' . esc_url($settings['logo_url']) . '" alt="' . esc_attr($company_name) . '" /></div>';
        }

        $initials = $this->initials($company_name);

        return '<div class="ccb-brand-mark ccb-brand-mark--text" aria-hidden="true">' . esc_html($initials) . '</div>';
    }

    private function render_settings_row($key, $label, $value, $type = 'text', $description = '')
    {
        printf(
            '<tr><th scope="row"><label for="ccb_%1$s">%2$s</label></th><td><input class="regular-text" type="%3$s" id="ccb_%1$s" name="%4$s[%1$s]" value="%5$s" />%6$s</td></tr>',
            esc_attr($key),
            esc_html($label),
            esc_attr($type),
            esc_attr(self::SETTINGS_KEY),
            esc_attr($value),
            $description ? '<p class="description">' . esc_html($description) . '</p>' : ''
        );
    }

    private function initials($text)
    {
        $parts = preg_split('/\s+/', trim((string) $text));
        $initials = '';

        foreach ($parts as $part) {
            if ('' === $part) {
                continue;
            }
            $initials .= strtoupper(substr($part, 0, 1));
            if (2 <= strlen($initials)) {
                break;
            }
        }

        return '' !== $initials ? $initials : 'CC';
    }

    private function css_variables($settings)
    {
        return sprintf('--ccb-accent:%1$s;--ccb-surface:%2$s;', $settings['accent_color'], $settings['surface_color']);
    }

    private function normalize_meta_list($value)
    {
        if (is_array($value)) {
            return array_values(array_filter(array_map('strval', $value)));
        }

        if (is_string($value) && '' !== $value) {
            return array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $value))));
        }

        return array();
    }

    private function format_posting_date($date_string)
    {
        if ('' === $date_string) {
            return '';
        }

        try {
            $timezone = wp_timezone();
            $date = new DateTimeImmutable($date_string, $timezone);
            $today = new DateTimeImmutable('today', $timezone);
            $days = (int) floor(($today->getTimestamp() - $date->setTime(0, 0)->getTimestamp()) / DAY_IN_SECONDS);

            if ($days <= 0) {
                return __('Posted today', 'company-careers-board');
            }

            if (1 === $days) {
                return __('Posted yesterday', 'company-careers-board');
            }

            if ($days < 7) {
                return sprintf(__('Posted %d days ago', 'company-careers-board'), $days);
            }

            if ($days < 30) {
                $weeks = (int) floor($days / 7);
                return sprintf(_n('Posted %d week ago', 'Posted %d weeks ago', $weeks, 'company-careers-board'), $weeks);
            }

            return sprintf(__('Posted %s', 'company-careers-board'), wp_date(get_option('date_format'), $date->getTimestamp(), $timezone));
        } catch (Exception $exception) {
            return '';
        }
    }

    private function excerpt_text($text, $length)
    {
        $text = trim(preg_replace('/\s+/', ' ', wp_strip_all_tags((string) $text)));

        if (strlen($text) <= $length) {
            return $text;
        }

        return rtrim(substr($text, 0, $length - 1)) . '...';
    }

    private function sanitize_hex($value, $fallback)
    {
        $value = trim((string) $value);

        if (preg_match('/^#[0-9a-fA-F]{6}$/', $value)) {
            return $value;
        }

        return $fallback;
    }

    private function meta_key($key)
    {
        return '_ccb_' . $key;
    }

    private function get_meta_fields()
    {
        return array(
            'company' => array('label' => __('Company', 'company-careers-board'), 'type' => 'text'),
            'location' => array('label' => __('Location', 'company-careers-board'), 'type' => 'text'),
            'type' => array('label' => __('Employment Type', 'company-careers-board'), 'type' => 'text'),
            'salary' => array('label' => __('Salary', 'company-careers-board'), 'type' => 'text'),
            'posting_date' => array('label' => __('Posting Date', 'company-careers-board'), 'type' => 'date', 'input_type' => 'date', 'description' => __('Used for sorting and the Posted label.', 'company-careers-board')),
            'apply_url' => array('label' => __('Apply URL', 'company-careers-board'), 'type' => 'url', 'description' => __('Leave blank to use the default brand apply URL.', 'company-careers-board')),
            'about_company' => array('label' => __('About Company', 'company-careers-board'), 'type' => 'textarea', 'rows' => 5),
            'description' => array('label' => __('Role Summary', 'company-careers-board'), 'type' => 'textarea', 'rows' => 5),
            'responsibilities' => array('label' => __('Responsibilities', 'company-careers-board'), 'type' => 'list', 'rows' => 6, 'description' => __('One item per line.', 'company-careers-board')),
            'qualifications' => array('label' => __('Qualifications', 'company-careers-board'), 'type' => 'list', 'rows' => 6, 'description' => __('One item per line.', 'company-careers-board')),
            'ideal_candidate' => array('label' => __('Ideal Candidate', 'company-careers-board'), 'type' => 'list', 'rows' => 5, 'description' => __('One item per line.', 'company-careers-board')),
            'additional_pay' => array('label' => __('Additional Pay', 'company-careers-board'), 'type' => 'textarea', 'rows' => 3),
            'benefits' => array('label' => __('Benefits', 'company-careers-board'), 'type' => 'list', 'rows' => 5, 'description' => __('One item per line.', 'company-careers-board')),
            'schedule' => array('label' => __('Schedule', 'company-careers-board'), 'type' => 'textarea', 'rows' => 3),
            'ability_to_commute' => array('label' => __('Commute / Relocation', 'company-careers-board'), 'type' => 'textarea', 'rows' => 3),
            'application_questions' => array('label' => __('Application Questions', 'company-careers-board'), 'type' => 'list', 'rows' => 4, 'description' => __('One item per line.', 'company-careers-board')),
            'education' => array('label' => __('Education', 'company-careers-board'), 'type' => 'text'),
            'work_location' => array('label' => __('Work Location', 'company-careers-board'), 'type' => 'text'),
            'job_types' => array('label' => __('Job Types', 'company-careers-board'), 'type' => 'text'),
        );
    }
}
