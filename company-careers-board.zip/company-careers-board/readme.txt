=== Company Careers Board ===
Contributors: openai
Tags: careers, jobs, hiring, recruiting, shortcode
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A white-label careers board plugin for WordPress with searchable job listings, brand controls, and fictional demo content.

== Description ==

Company Careers Board is designed to be resold or reused across clients. It gives you:

* A dedicated WordPress admin area for managing job listings
* Brand settings for company name, headline, accent color, and logo URL
* A public shortcode-based careers experience
* A demo importer with fictional listings for staging, screenshots, or product demos

Use the shortcode:

[company_careers_board]

== Installation ==

1. Upload the `company-careers-board` folder to `/wp-content/plugins/`
2. Activate the plugin in WordPress
3. Go to `Careers Board > Setup`
4. Save the brand settings you want to use
5. Import the demo jobs if needed
6. Add `[company_careers_board]` to any page

== FAQ ==

= Can I replace the fictional listings? =

Yes. The demo import is optional. You can edit or delete the imported jobs at any time and create your own.

= Can I reuse this for multiple clients? =

Yes. The plugin is structured as a generic, white-label careers board and ships with fictional demo content instead of client-specific branding.
